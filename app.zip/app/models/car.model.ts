export class Car {
id: number;
name: string;
brand: string;
cost : string;
features: string;
year: Date;
availability: string;
photoPath?:string;
}
